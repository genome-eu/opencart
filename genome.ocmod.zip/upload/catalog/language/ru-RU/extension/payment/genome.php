<?php
/**
 * 2020 Genome
 * @copyright 2020 Genome
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

$_['heading_title']  = 'Способы оплаты Paysera';

$_['text_title']     = 'Способы оплаты Paysera';
$_['text_chosen']    = 'Оплатить через систему Paysera';

$_['button_confirm'] = 'Подтвердить заказ';