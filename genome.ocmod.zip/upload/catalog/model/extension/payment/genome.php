<?php
/**
 * 2018 Genome
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@genome.com so we can send you a copy immediately.
 *
 *  @author    Genome <plugins@genome.com>
 *  @copyright 2018 Genome
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of Genome
 */

class ModelExtensionPaymentGenome extends Model
{
    /**
     * Genome module code
     */
    const GENOME_CODE = 'genome';

    /**
     * Genome module status config
     */
    const CONFIG_GENOME_ENABLE = 'payment_genome_status';

    /**
     * Genome title config
     */
    const CONFIG_GENOME_TITLE = 'payment_genome_title';

    /**
     * Genome geo config
     */
    const CONFIG_GENOME_GEO = 'payment_genome_geo_zone_id';

    /**
     * Genome total config
     */
    const CONFIG_GENOME_TOTAL = 'payment_genome_total';

    /**
     * Genome payment sort config
     */
    const CONFIG_GENOME_SORT = 'payment_genome_sort_order';

    /**
     * Empty value
     */
    const EMPTY_VAL = '';

    /**
     * Zero value
     */
    const ZERO_VAL = 0;

    /**
     * @param object $address
     * @param double $total
     *
     * @return array
     */
    public function getMethod($address, $total)
    {
        $this->load->language('extension/payment/genome');

        if ($this->config->get($this::CONFIG_GENOME_ENABLE)) {
            $geoZoneID = (int)$this->config->get($this::CONFIG_GENOME_GEO);
            $countryID = (int)$address['country_id'];

            $zoneID    = (int)$address['zone_id'];
            $zones     = implode(',', array($zoneID, $this::ZERO_VAL));

            $query = $this->db->query(
                "SELECT * FROM " . DB_PREFIX . "zone_to_geo_zone"
                . " WHERE geo_zone_id = '" . $geoZoneID
                . "' AND country_id = '" . $countryID
                . "' AND zone_id IN (" . $zones . ")"
            );

            if (
                $this->config->get($this::CONFIG_GENOME_TOTAL) > 0
                && $this->config->get($this::CONFIG_GENOME_TOTAL) > $total
            ) {
                $status = false;
            } elseif (
            !$this->config->get($this::CONFIG_GENOME_GEO)
            ) {
                $status = true;
            } elseif ($query->num_rows) {
                $status = true;
            } else {
                $status = false;
            }
        } else {
            $status = false;
        }

        $method_data = array();

        $title = $this->config->get($this::CONFIG_GENOME_TITLE);
        if (empty($title)) {
            $title = $this->language->get('text_title');
        }

        $sort = $this->config->get($this::CONFIG_GENOME_SORT);

        if ($status) {
            $method_data = array(
                'code'       => 'genome',
                'title'      => $title,
                'terms'      => $this::EMPTY_VAL,
                'sort_order' => $sort
            );
        }

        return $method_data;
    }
}