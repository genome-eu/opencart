<?php
/**
 * 2020 Genome
 * @copyright 2020 Genome
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

require_once DIR_SYSTEM . 'library/genome/vendor/autoload.php';

use Genome\Lib\Genome\Scriney;
use Genome\Lib\Util\SignatureHelper;
use Genome\Lib\Util\StringHelper;

/**
 * Class ControllerExtensionPaymentGenome
 */
class ControllerExtensionPaymentGenome extends Controller
{
    /**
     * Default code value
     */
    const CODE = 'code';

    /**
     * Certificate
     */
    const SSL = 'SSL';

    /**
     * Empty value
     */
    const EMPTY_CODE = '';

    /**
     * New int value
     */
    const NEW_VALUE = 1;

    /**
     * Decimal places
     */
    const DECIMALS_ROUND = 2;

    /**
     * Genome public key
     */
    const CONFIG_GENOME_PUBLIC_KEY = 'payment_genome_public_key';

    /**
     * Genome project privat key
     */
    const CONFIG_GENOME_PRIVAT_KEY = 'payment_genome_privat_key';

    /**
     * Genome public key
     */
    const CONFIG_GENOME_PUBLIC_TEST_KEY = 'payment_genome_public_test_key';

    /**
     * Genome project privat key
     */
    const CONFIG_GENOME_PRIVAT_TEST_KEY = 'payment_genome_privat_test_key';

    /**
     * genome test config name
     */
    const CONFIG_GENOME_TEST = 'payment_genome_test';

    /**
     * genome response status success
     */
    const CONFIG_GENOME_RESPONSE_SUCCESS = 'success';

    /**
     * genome response status decline
     */
    const CONFIG_GENOME_RESPONSE_DECLINE = 'decline';

    /**
     * genome response status error
     */
    const CONFIG_GENOME_RESPONSE_ERROR = 'error';

    /**
     * Genome new order config name
     */
    const CONFIG_NEW_STATUS = 'payment_genome_new_order_status_id';

    /**
     * genome canceled order config name
     */
    const CONFIG_CANCELED_STATUS = 'payment_genome_canceled_status_id';

    /**
     * Genome paid order config name
     */
    const CONFIG_PAID_STATUS = 'payment_genome_paid_status_id';

    /**
     * Genome refunded order config name
     */
    const CONFIG_REFUNDED_STATUS = 'payment_genome_refunded_status_id';

    /**
     * Display errors setter
     */
    const DISPLAY_ERROR = 'display_errors';

    /**
     * Template config name
     */
    const TEMPLATE_NAME = 'config_template';

    /**
     * Store config name
     */
    const STORE_NAME = 'config_store';

    /**
     * Genome template function
     */
    const GENOME_TEMPLATE = '/template/extension/payment/genome';

    /**
     * Genome function
     */
    const GENOME_EXTENSION = 'extension/payment/genome';

    /**
     * accepturl
     */
    const ACCEPT_URL = 'index.php?route=extension/payment/genome/accept';

    /**
     * cancelurl
     */
    const CANCEL_URL = 'index.php?route=extension/payment/genome/cancel';

    /**
     * callbackurl
     */
    const CALLBACK_URL = 'index.php?route=extension/payment/genome/callback';

    /**
     * Guest
     */
    const GENOME_GUEST = 'checkout/guest/confirm';

    /**
     * Checkout page
     */
    const CHECKOUT_PAYMENT = 'index.php?route=checkout/payment';

    /**
     * Guest checkout
     */
    const CHECKOUT_GUEST = 'index.php?route=checkout/guest';

    private $responsData;
    private $orderId;
    private $transactionId;
    private $userId;
    private $userEmail;
    private $amount;
    private $responseStatus;
    private $responseMessage;
    private $responseCode;

    private function getPublicKey()
    {
        if ($this->config->get($this::CONFIG_GENOME_TEST)) {
            return $this->config->get($this::CONFIG_GENOME_PUBLIC_TEST_KEY);
        } else {
            return $this->config->get($this::CONFIG_GENOME_PUBLIC_KEY);
        }
    }

    private function getPrivateKey()
    {
        if ($this->config->get($this::CONFIG_GENOME_TEST)) {
            return $this->config->get($this::CONFIG_GENOME_PRIVAT_TEST_KEY);
        } else {
            return $this->config->get($this::CONFIG_GENOME_PRIVAT_KEY);
        }
    }


    public function prepare_form($order)
    {
        $productData[] = [
            "productId" => $order['order_id'],
            "productType" => "fixedProduct",
            "productName" => "Order #" . $order['order_id'],
            "currency" => $order['currency_code'],
            "amount" => $order['total']
        ];

        $params = [
            "email" => $order['email'],
            "uniqueUserId" => $order['email'],
            "firstname" => $order['payment_firstname'] ?? '',
            "lastname" => $order['payment_lastname'] ?? '',
         //   "phone" => $this->validatePhone($order['telephone']),
            "address" => $order['payment_address_1'] ?? '',
            "city" => $order['payment_city'] ?? '',
            "country" => $order['payment_country'] ?? '',
            "zip" => $order['payment_postcode'] ?? '',
            "key" => $this->getPublicKey(),
            "payment_method" => 'Credit card',
            "uniqueTransactionId" => $this->generateTransactionId($order['customer_id'], $order['order_id']),
            "customProduct" => json_encode($productData),
        ];

        $signature = (new SignatureHelper())->generateForArray($params, $this->getPrivateKey(), true);

        $params['signature'] = $signature;

        return $params;
    }

    public function validatePhone($phone = '')
    {
        if ($this->config->get($this::CONFIG_GENOME_TEST)) {
            if (!empty($phone)) {
                $plus = $rest = substr($phone, 0, 1);
                if ($plus != '+') {
                    $phone = '+' . $phone;
                }
            }
        }
        return $phone;
    }


    public function pay_for_order($order)
    {
        $this->load->language($this::GENOME_EXTENSION);

        $formData = $this->prepare_form($order);
        $formTxt = '';

        $stringHelper = new StringHelper();

        foreach ($formData as $key => $value) {
            $formTxt .= '<input type="hidden" name="' . $stringHelper->encodeHtmlAttribute($key) . '" 
            value="' . $stringHelper->encodeHtmlAttribute($value) . '">';
        }

        return '<form action="https://hpp-service.genome.eu/hpp" class=\'redirect_form\'  method="post">' . $formTxt .
            '<button type="submit" class="btn btn-primary"  style="display: block;" id="submit-form">' . $this->language->get('button_confirm') . '</button>
             </form>
           <!--   <script>jQuery( "#submit-form" ).click();</script>-->';

    }

    /**
     * @return mixed
     */
    public function index()
    {
        $this->load->language($this::GENOME_EXTENSION);

        if ($this->request->get['route'] != $this::GENOME_GUEST) {
            $data['back'] = HTTPS_SERVER . $this::CHECKOUT_PAYMENT;
        } else {
            $data['back'] = HTTPS_SERVER . $this::CHECKOUT_GUEST;
        }

        $this->load->model('checkout/order');

        $orderID = $this->session->data['order_id'];
        $order = $this->model_checkout_order->getOrder($orderID);

        $data['form'] = $this->pay_for_order($order);

        if (file_exists(DIR_TEMPLATE . $this->config->get($this::TEMPLATE_NAME) . $this::GENOME_TEMPLATE)) {
            return $this->load->view($this->config->get($this::TEMPLATE_NAME) . $this::GENOME_TEMPLATE, $data);
        } else {
            return $this->load->view($this::GENOME_EXTENSION, $data);
        }
    }


    public function cancel()
    {
        $this->load->model('checkout/order');
        $orderID = $this->session->data['order_id'];
        $order = $this->model_checkout_order->getOrder($orderID);
        $comment = json_encode($_POST);
        $scriney = new \Genome\Scriney($this->getPublicKey(), $this->getPrivateKey());

        if ($order && $scriney->validateApiResult($_POST)) {
            $declineStatus = $this->config->get($this::CONFIG_CANCELED_STATUS);

            $this->model_checkout_order->addOrderHistory(
                $orderID, $declineStatus, $comment
            );
        }

        $this->decline();
        //$this->response->redirect($this->url->link('checkout/failure', $this::EMPTY_CODE, true));
    }

    public function decline()
    {

        $this->load->language('extension/payment/genome');

        $this->document->setTitle($this->language->get('heading_title_failed'));

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_basket'),
            'href' => $this->url->link('checkout/cart')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_checkout'),
            'href' => $this->url->link('checkout/checkout', '', true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_failure'),
            'href' => $this->url->link('checkout/failure')
        );

        $data['text_message'] = sprintf($this->language->get('decline_text_message'), $this->url->link('information/contact'));

        $data['continue'] = $this->url->link('checkout/cart');
        $data['button_continue'] = $this->language->get('button_back_to_cart');

        $data['column_left'] = $this->load->controller('common/column_left');
        $data['column_right'] = $this->load->controller('common/column_right');
        $data['content_top'] = $this->load->controller('common/content_top');
        $data['content_bottom'] = $this->load->controller('common/content_bottom');
        $data['footer'] = $this->load->controller('common/footer');
        $data['header'] = $this->load->controller('common/header');
        $data['heading_title'] = $this->language->get('heading_title_failed');

        $this->response->setOutput($this->load->view('common/success', $data));

    }

    public function accept()
    {
        $this->load->model('checkout/order');
        $orderID = $this->session->data['order_id'];
        $order = $this->model_checkout_order->getOrder($orderID);
        $comment = json_encode($_POST);

        $scriney = new \Genome\Scriney($this->getPublicKey(), $this->getPrivateKey());

        if ($order && $scriney->validateApiResult($_POST)) {

            $currentStatus = $order['order_status_id'];
            $paidStatus = $this->config->get($this::CONFIG_PAID_STATUS);
            $newStatus = $this->config->get($this::CONFIG_NEW_STATUS);
            if ($currentStatus !== $paidStatus) {
                $this->model_checkout_order->addOrderHistory(
                    $orderID, $newStatus, $comment
                );
            }

            $this->response->redirect($this->url->link('checkout/success', $this::EMPTY_CODE, true));
        } else {
            $comment = implode("\r\n", $_POST);
            $canceledStatus = $this->config->get($this::CONFIG_CANCELED_STATUS);
            $this->model_checkout_order->addOrderHistory(
                $orderID, $canceledStatus, $comment
            );

            $this->response->redirect($this->url->link('checkout/cart', $this::EMPTY_CODE, true));
        }
    }

    public function callback()
    {
        $headers = $this->getHeaders();
        $this->responsData = file_get_contents('php://input');

        file_put_contents('callback.log', $this->responsData, FILE_APPEND);

        $scriney = new \Genome\Scriney($this->getPublicKey(), $this->getPrivateKey());

        try {
            if ($scriney->validateCallback($this->responsData, $headers)) {
                $data = json_decode($this->responsData, true);
                $this->parseResponse($data);
                $this->validateOrder($this->orderId);

                if ($this->responseStatus == $this::CONFIG_GENOME_RESPONSE_SUCCESS) {
                    $this->genome_complete_order();
                } elseif ($this->responseStatus == $this::CONFIG_GENOME_RESPONSE_ERROR) {
                    $this->genome_error_order();
                } else {
                    $this->genome_error_order();
                }
            }
            exit('OK');

        } catch (Exception $e) {
            exit(get_class($e) . ': ' . $e->getMessage());
        }
    }

    /**
     * Parse callback params from response
     * @param array $data
     * @return void
     */
    private function parseResponse(array $data)
    {
        $transaction = explode('-', $data['uniqueTransactionId']);
        $this->userId = $transaction[0];
        $this->orderId = $transaction[1];
        $this->transactionId = $data['reference'];
        $this->userEmail = $data['uniqueUserId'];
        $this->amount = $data['totalAmount'];
        $this->responseStatus = $data['status'];
        $this->responseMessage = $data['message'];
        $this->responseCode = $data['code'];
    }

    /**
     * check if the order exists
     * @param int $orderId
     * @return void
     */
    public function validateOrder(int $orderId)
    {
        $this->load->model('checkout/order');
        $order = $this->model_checkout_order->getOrder($orderId);
        if (empty($order)) {
            throw new Exception('Order with this ID not found');
        }
    }

    public function genome_complete_order()
    {
        $orderStatus = $this->config->get($this::CONFIG_PAID_STATUS);
        $this->model_checkout_order->addOrderHistory($this->orderId, $orderStatus);
    }

    public function genome_decline_order()
    {
        $orderStatus = $this->config->get($this::CONFIG_CANCELED_STATUS);
        $this->model_checkout_order->addOrderHistory($this->orderId, $orderStatus, $this->responsData);
    }

    public function genome_error_order()
    {
        $orderStatus = $this->config->get($this::CONFIG_CANCELED_STATUS);
        $this->model_checkout_order->addOrderHistory($this->orderId, $orderStatus, $this->responsData);
    }

    public function update_order(&$route, &$data, &$output)
    {
        $orderId = $data[0];
        $statusId = $data[1];

        $r[] = $orderId;
        $r[] = $statusId;
        $r[] = $this->config->get($this::CONFIG_REFUNDED_STATUS);


        if ($statusId == $this->config->get($this::CONFIG_REFUNDED_STATUS)) {

            $this->load->model('checkout/order');
            $order = $this->model_checkout_order->getOrder($orderId);
            $transactionId = $this->generateTransactionId($order['customer_id'], $orderId);


            $scriney = new \Genome\Scriney($this->getPublicKey(), $this->getPrivateKey());
            $result = $scriney->refund($transactionId, $order['total'], $order['currency_code']);

            file_put_contents('update.log', json_encode($result), FILE_APPEND);
        }
    }

    public function generateTransactionId(int $customerId, int $orderId)
    {
        return $customerId . '-' . str_pad($orderId, 6, '0', STR_PAD_LEFT);
    }

    /**
     * get headers from request.
     * @return array
     */
    private function getHeaders()
    {
        $headers = [];
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}
