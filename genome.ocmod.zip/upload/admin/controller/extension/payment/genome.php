<?php
/**
 * 2020 Genome
 * @copyright 2020 Genome
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

/**
 * Class ControllerExtensionPaymentGenome
 */
class ControllerExtensionPaymentGenome extends Controller
{
    /**
     * Default currency
     */
    const GENOME_CURRENCY = 'EUR';

    /**
     * Default language code
     */
    const GENOME_DEFAULT_LANG = 'en';

    /**
     * Empty value
     */
    const GENOME_EMPTY_VALUE = '';

    /**
     * Default method
     */
    const REQUEST_METHOD_TYPE = 'POST';

    /**
     * Default project id
     */
    const GENOME_DEFAULT_PROJECT_ID = 1;

    /**
     * genome payment module name
     */
    const GENOME_PAYMENT = 'payment_genome';

    /**
     * Success text
     */
    const GENOME_SUCCESS = 'text_success';

    /**
     * genome extension function
     */
    const GENOME_EXTENSION_PAYMENT = 'extension/payment/genome';

    /**
     * Marketplace extension location
     */
    const GENOME_MARKETPLACE_EXTENSIONS = 'marketplace/extension';

    /**
     * Dashboard
     */
    const GENOME_COMMON_DASHBOARD = 'common/dashboard';

    /**
     * Prefix used with an error code
     */
    const GENOME_ERROR_PREFIX = 'error_';

    /**
     * Callback url
     */
    const GENOME_CALLBACK_URL = 'index.php?route=extension/payment/genome/callback';

    /**
     * Token param
     */
    const GENOME_TOKEN_PARAM = 'user_token=';

    /**
     * Token value
     */
    const GENOME_TYPE_PAYMENT = '&type=payment';

    /**
     * genome header hook controller
     */
    const GENOME_HEADER_CONTROLER = 'extension/payment/genome/genome_header';

    /**
     * genome footer hook controller
     */
    const GENOME_FOOTER_CONTROLER = 'extension/payment/genome/genome_footer';

    /**
     * genome order update hook event
     */
    const GENOME_EVENT_ORDER_UPDATE = 'model/checkout/order/addOrderHistory/after';

    /**
     * genome order update event name
     */
    const GENOME_EVENT_ORDER_UPDATE_NAME = 'genome_order_update';

    /**
     * genome order update hook controller
     */
    const GENOME_EVENT_ORDER_UPDATE_CONTROLER = 'extension/payment/genome/update_order';


    /**
     * @var array
     */
    private $error = array();

    /**
     * @var array
     */
    private $errorFieldName = array(
        'warning',
        'public_key',
        'privat_key',
        'public_test_key',
        'privat_test_key'
    );

    /**
     * @var array
     */
    private $breadcrumbFields = array(
        'text_home'      => 'common/dashboard',
        'text_extension' => 'marketplace/extension',
        'heading_title'  => 'extension/payment/genome'
    );

    /**
     * @var array
     */
    private $genomeFieldsName = array(
        'payment_genome_status',
        'payment_genome_public_key',
        'payment_genome_public_test_key',
        'payment_genome_privat_key',
        'payment_genome_privat_test_key',
        'payment_genome_test',
        'payment_genome_total',
        'payment_genome_title',
        'payment_genome_description',
        'payment_genome_new_order_status_id',
        'payment_genome_paid_status_id',
        'payment_genome_pending_status_id',
        'payment_genome_refunded_status_id',
        'payment_genome_canceled_status_id',
    );

    public function index()
    {
        $this->load->language('extension/payment/genome');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('setting/setting');

        if ($this->request->server['REQUEST_METHOD'] == $this::REQUEST_METHOD_TYPE
            && $this->validate()) {
            $this->model_setting_setting->editSetting(
                $this::GENOME_PAYMENT,
                $this->request->post
            );

            $this->session->data['success'] = $this->generateData(
                $this::GENOME_SUCCESS,
                $this::GENOME_EMPTY_VALUE
            );
        }

        foreach ($this->getErrorFieldName() as $fieldName) {
            $dataName = $this::GENOME_ERROR_PREFIX . $fieldName;
            $data[$dataName] = $this->errorValue($fieldName);
        }

        foreach ($this->getBreadcrumbFields() as $key => $value) {
            $data['breadcrumbs'][] = $this->generateData($key, $value);
        }

        $data['action'] = $this->generateData(
            $this::GENOME_EMPTY_VALUE,
            $this::GENOME_EXTENSION_PAYMENT
        );
        $data['cancel'] = $this->generateData(
            $this::GENOME_EMPTY_VALUE,
            $this::GENOME_MARKETPLACE_EXTENSIONS
        );
        $data['callback'] = HTTP_CATALOG . $this::GENOME_CALLBACK_URL;

        foreach ($this->getGenomeFieldsName() as $fieldName) {
            $data[$fieldName] = $this->generateConfigField($fieldName);
        }


        $this->load->model('localisation/order_status');

        $data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

        $data['header']      = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer']      = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view($this::GENOME_EXTENSION_PAYMENT, $data));
    }

    /**
     * @return bool
     */
    protected function validate()
    {
        if (!$this->user->hasPermission('modify', $this::GENOME_EXTENSION_PAYMENT)) {
            $this->error['warning'] = $this->language->get('error_warning');
        }

        if (!$this->request->post['payment_genome_public_key']) {
            $this->error['public_key'] = $this->language->get('error_public_key');
        }

        if (!$this->request->post['payment_genome_privat_key']) {
            $this->error['privat_key'] = $this->language->get('error_privat_key');
        }

        return !$this->error;
    }

    /**
     * @param string $fieldName
     *
     * @return string
     */
    private function errorValue($fieldName)
    {
        if (isset($this->error[$fieldName])) {
            $data = $this->error[$fieldName];
        } else {
            $data = $this::GENOME_EMPTY_VALUE;
        }

        return $data;
    }

    /**
     * @param string $text
     * @param string $path
     *
     * @return array
     */
    private function generateData($text, $path)
    {
        if ($path == $this::GENOME_MARKETPLACE_EXTENSIONS) {
            $tokenParam = $this::GENOME_EMPTY_VALUE;
        } else {
            $tokenParam = $this::GENOME_TYPE_PAYMENT;
        }
        $token = $this::GENOME_TOKEN_PARAM . $this->session->data['user_token'] . $tokenParam;

        if (empty($text)) {
            $data = $this->url->link($path, $token, true);
        } elseif (empty($path)) {
            $data = $this->language->get($text);
        } else {
            $data = array(
                'text' => $this->language->get($text),
                'href' => $this->url->link($path, $token, true)
            );
        }

        return $data;
    }

    /**
     * @param string $fieldName
     *
     * @return mixed
     */
    private function generateConfigField($fieldName)
    {
        if (isset($this->request->post[$fieldName])) {
            $data = $this->request->post[$fieldName];
        } else {
            $data = $this->config->get($fieldName);
        }

        return $data;
    }

    /**
     * @return array
     */
    private function getErrorFieldName()
    {
        return $this->errorFieldName;
    }

    /**
     * @return array
     */
    private function getGenomeFieldsName()
    {
        return $this->genomeFieldsName;
    }

    /**
     * @return array
     */
    public function getBreadcrumbFields()
    {
        return $this->breadcrumbFields;
    }

    public function install() {
        $this->load->model('setting/event');

        $this->model_setting_event->addEvent(
            $this::GENOME_EVENT_ORDER_UPDATE_NAME,
            $this::GENOME_EVENT_ORDER_UPDATE,
            $this::GENOME_EVENT_ORDER_UPDATE_CONTROLER)
        ;
    }

    public function uninstall() {
        $this->load->model('setting/event');

        $this->model_setting_event->deleteEventByCode($this::GENOME_EVENT_ORDER_UPDATE_NAME);
    }
}
